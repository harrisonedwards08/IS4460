string1 = "UYDSM01BRL9"
var1 = len(string1)
print (var1)