



thisvariable = 1
thisreference = thisvariable
thisreference = 2
print(thisvariable,thisreference)