def title_names (names:list):
    new_names = [x.title() for x in names]
    return new_names