from django.apps import AppConfig


class HW2AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'HW2App'
