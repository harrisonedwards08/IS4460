import os

import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'HW2Project.settings')

django.setup()