from django import forms

class FeedbackForm(forms.Form):

    my_message = forms.CharField(label='Feedback Message', widget=forms.Textarea)
    your_name = forms.CharField(max_length=25)
    review_area = forms.MultipleChoiceField(choices=[('food', 'food'),('srvc', 'service'),('amb', 'ambiance'),('music', 'music')], 
        widget=forms.CheckboxSelectMultiple)



    def clean_my_message(self):
        
        my_message: str = self.cleaned_data.get('my_message')
        
        if "bad" in my_message:
            raise forms.ValidationError(f"ur bad")
        
        return my_message

